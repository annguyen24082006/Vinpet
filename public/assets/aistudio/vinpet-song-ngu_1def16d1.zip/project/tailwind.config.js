/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        sapphire: {
          50: '#F4F0FB',
          100: '#E8DFF7',
          200: '#D2BEEF',
          300: '#B196E3',
          400: '#8C6AD0',
          500: '#6B45B8',
          600: '#54339C',
          700: '#43287D',
          800: '#342062',
          900: '#26174A',
          950: '#180E33',
        },
        gold: {
          50: '#FBF7E8',
          100: '#F7EDC9',
          200: '#EFD98C',
          300: '#E7C75A',
          400: '#D4AF37',
          500: '#C19A2A',
          600: '#A87E1F',
          700: '#86601A',
          800: '#604517',
          900: '#3E2D10',
        },
        ivory: '#FBF8F1',
        cream: '#F5EFE2',
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'serif'],
        sans: ['Nunito', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        gold: '0 10px 40px -12px rgba(196, 154, 42, 0.45)',
        sapphire: '0 10px 40px -12px rgba(83, 51, 156, 0.5)',
        soft: '0 6px 30px -10px rgba(38, 23, 74, 0.18)',
      },
      backgroundImage: {
        'sapphire-radial':
          'radial-gradient(circle at 20% 10%, rgba(139,106,208,0.35), transparent 45%), radial-gradient(circle at 85% 90%, rgba(196,154,42,0.28), transparent 50%)',
        'gold-sheen':
          'linear-gradient(115deg, #C19A2A 0%, #E7C75A 30%, #FBF7E8 50%, #E7C75A 70%, #A87E1F 100%)',
      },
      keyframes: {
        floatUp: {
          '0%': { transform: 'translateY(14px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        slowZoom: {
          '0%': { transform: 'scale(1)' },
          '100%': { transform: 'scale(1.12)' },
        },
        twinkle: {
          '0%, 100%': { opacity: '0.3', transform: 'scale(0.7)' },
          '50%': { opacity: '1', transform: 'scale(1)' },
        },
      },
      animation: {
        floatUp: 'floatUp 0.7s cubic-bezier(0.22,1,0.36,1) both',
        shimmer: 'shimmer 6s linear infinite',
        slowZoom: 'slowZoom 18s ease-in-out infinite alternate',
        twinkle: 'twinkle 3s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
