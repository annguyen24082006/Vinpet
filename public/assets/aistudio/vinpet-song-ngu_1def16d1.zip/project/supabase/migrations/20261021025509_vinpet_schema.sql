/*
# VinPet - Schema for pet hotel/resort booking, daycare, events, newsletter

1. New Tables
- `bookings` - Đặt phòng + gói dịch vụ VinPet cho thú cưng
  - id, contact_name, contact_email, contact_phone, destination, room_type, pet_package, pet_name, pet_breed, pet_weight_kg, vaccination_note, special_note, consent_confirmed, payment_method, confirmation_code, status, created_at
- `daycare_bookings` - Đặt lịch trông giữ theo giờ/ngày
  - id, contact_name, contact_email, contact_phone, pet_name, pet_breed, slot_date, slot_start, slot_end, package, pin_code, status, created_at
- `event_inquiries` - Form tư vấn tổ chức tiệc sự kiện
  - id, contact_name, contact_email, contact_phone, human_count, pet_count, budget, event_type, preferred_date, note, status, created_at
- `newsletter_subscribers` - Đăng ký nhận bản tin
  - id, email (unique), created_at

2. Security
- Single-tenant (no auth) — all policies TO anon, authenticated.
- RLS enabled on every table; public read+write per single-tenant pattern.
- newsletter_subscribers email unique to avoid duplicates.

3. Notes
- confirmation_code và pin_code sinh ở frontend (ngẫu nhiên), ghi xuống DB.
- status defaults: 'pending' for booking/event, 'confirmed' for daycare.
*/

CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_name text NOT NULL,
  contact_email text NOT NULL,
  contact_phone text NOT NULL,
  destination text NOT NULL,
  room_type text NOT NULL,
  pet_package text NOT NULL,
  pet_name text NOT NULL,
  pet_breed text,
  pet_weight_kg numeric,
  vaccination_note text,
  special_note text,
  consent_confirmed boolean NOT NULL DEFAULT false,
  payment_method text NOT NULL DEFAULT 'vnpay',
  confirmation_code text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS daycare_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_name text NOT NULL,
  contact_email text NOT NULL,
  contact_phone text NOT NULL,
  pet_name text NOT NULL,
  pet_breed text,
  slot_date date NOT NULL,
  slot_start text NOT NULL,
  slot_end text NOT NULL,
  package text NOT NULL DEFAULT 'hourly',
  pin_code text NOT NULL,
  status text NOT NULL DEFAULT 'confirmed',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS event_inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_name text NOT NULL,
  contact_email text NOT NULL,
  contact_phone text NOT NULL,
  human_count int DEFAULT 1,
  pet_count int DEFAULT 1,
  budget text,
  event_type text NOT NULL,
  preferred_date date,
  note text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE daycare_bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_crud_bookings" ON bookings;
CREATE POLICY "anon_select_bookings" ON bookings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_bookings" ON bookings FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_bookings" ON bookings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_bookings" ON bookings FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_daycare" ON daycare_bookings;
CREATE POLICY "anon_select_daycare" ON daycare_bookings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_daycare" ON daycare_bookings FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_daycare" ON daycare_bookings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_daycare" ON daycare_bookings FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_events" ON event_inquiries;
CREATE POLICY "anon_select_events" ON event_inquiries FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_events" ON event_inquiries FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_events" ON event_inquiries FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_events" ON event_inquiries FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_newsletter" ON newsletter_subscribers;
CREATE POLICY "anon_select_newsletter" ON newsletter_subscribers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_newsletter" ON newsletter_subscribers FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_newsletter" ON newsletter_subscribers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_newsletter" ON newsletter_subscribers FOR DELETE TO anon, authenticated USING (true);
